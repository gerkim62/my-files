// TODO: background script
chrome.runtime.onInstalled.addListener(() => {
  // TODO: on installed function
})
