import React from 'react'

type Props = {
    
}

const index = (props: Props) => {
  return (
    <div>index</div>
  )
}