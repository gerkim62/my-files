const Moodle = window.M || null;

if (Moodle) {
  const sesskey = Moodle.cfg.sesskey;
  const rootUrl = Moodle.cfg.wwwroot;
  const logoutUrl = `${rootUrl}/login/logout.php?sesskey=${sesskey}`;

  console.log("is a moodle page");
  //   console.log("logout url", logoutUrl);

  //add hidden input with logout url
  const logoutInput = document.createElement("input");
  logoutInput.type = "hidden";
  logoutInput.id = "logoutUrl";
  logoutInput.value = logoutUrl;
  document.body.appendChild(logoutInput);

  //   const added = document.getElementById("logoutUrl");
  //   console.log(added.value, "added");
}
