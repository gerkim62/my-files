import { useSession } from "next-auth/react";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";

export function usePushNotificationsPrompt() {
  const { data: session } = useSession();
  const [notificationsSupported, setNotificationSupported] = useState(false);
  const [alreadyPrompted, setAlreadyPrompted] = useState(false);
  const [subscribed, setSubscribed] = useState(false);
  const [showing, setShowing] = useState(false);
  const [overlayShowing, setOverlayShowing] = useState(false);

  useEffect(() => {
    checkNotificationSupport();
    checkAlreadyPrompted();
    checkSubscription();
  }, []);

  useEffect(() => {
    setShowing(notificationsSupported && !alreadyPrompted && !subscribed);
  }, [notificationsSupported, alreadyPrompted, subscribed]);

  async function checkNotificationSupport() {
    setNotificationSupported("Notification" in window);
  }

  function checkAlreadyPrompted() {
    setAlreadyPrompted(
      localStorage.getItem("notifications-prompted") === "true"
    );
  }

  async function checkSubscription() {
    const register = await navigator.serviceWorker.getRegistration();

    if (!register) return;

    const registration = await register.pushManager.getSubscription();
    if (registration) {
      console.log("Already subscribed", registration);
      setSubscribed(true);
    }
  }

  async function handleClick() {
    let accepted = Notification.permission === "granted";

    if (!accepted) {
      setOverlayShowing(true);
      const choice = await Notification.requestPermission();
      setOverlayShowing(false);
      accepted = choice === "granted";
    }

    setShowing(false);

    if (accepted) {
      const subscription = await subscribePush();
      if (!subscription) {
        toast.error("Can't generate notification subscription.");
        return;
      }

      const success = await saveSubscription(subscription);
      if (success) {
        setSubscribed(true);
        toast.success("Notifications enabled successfully");
        localStorage.setItem("notifications-prompted", "true");
      } else {
        toast.error("Failed to save subscription. Please retry.");
      }
    } else {
      toast.error("Failed to enable notifications");
    }

    if (Notification.permission !== "default" && subscribed) {
      localStorage.setItem("notifications-prompted", "true");
    }
  }

  async function subscribePush() {
    const publicVapidKey =
      process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY ||
      "BHU8mT0M4T8l0n0kM5HME-IKFVqQlbsEbQDD5ihoWrb3QodZA5LAMoujrI7gmqvFxEv3n9oy0gmfE00Hhv4NI4w";
    if (!publicVapidKey) return console.log("VAPID key not found");

    console.log("Checking service worker registration...");
    const register = await navigator.serviceWorker.getRegistration();

    if (!register) {
      return console.log("Service worker not found");
    }
    if (!publicVapidKey) return console.log("VAPID key not found");
    // Register Push
    console.log("Registering Push...");
    const subscription = await register.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(publicVapidKey),
    });
    console.log("Push Registered...");

    return subscription;
  }

  async function saveSubscription(subscription: PushSubscription) {
    const userId = (session?.user as any)?.id;
    if (!userId)
      throw new Error("No user id hence cannot save push subscription");
    const response = await fetch("/api/notifications/save-subscription", {
      method: "POST",
      body: JSON.stringify({
        subscription,
        userId,
      }),
    }).catch((error) => {
      console.error(error);
      throw new Error("Failed to get response when saving subscription");
    });

    if (!response.ok)
      throw new Error(
        "Server returned bad status code when saving subscription"
      );

    return true;
  }

  function urlBase64ToUint8Array(base64String: string) {
    const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding)
      .replace(/\-/g, "+")
      .replace(/_/g, "/");

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  return {
    notificationsSupported,
    alreadyPrompted,
    subscribed,
    showing,
    overlayShowing,
    setOverlayShowing,
    subscribePush,
    saveSubscription,
    handleClick,
  };
}
