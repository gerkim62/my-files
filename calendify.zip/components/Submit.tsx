"use client";

import React, { ReactNode } from "react";
import { useFormStatus } from "react-dom";

type SubmitProps = {
  children: ReactNode;
  pendingChildren?: ReactNode;
  className: string;
};

const Submit = ({ children, pendingChildren, className }: SubmitProps) => {
  const { pending, data, method, action } = useFormStatus();
  return (
    <button
      type="submit"
      className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-r"
    >
      {pending ? pendingChildren ?? children : children}
      {/* {pending ? "Submitting..." : "Submit"} */}
    </button>
  );
};

export default Submit;
