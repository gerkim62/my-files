"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";

const Page: React.FC = () => {
  const router = useRouter();
  const { data: session, status } = useSession();
  const [notificationsSupported, setNotificationSupported] = useState(false);
  const [alreadyPrompted, setAlreadyPrompted] = useState(false);

  // overlay show state
  const [overlayShowing, setOverlayShowing] = useState(false);
  const [subscribed, setSubscribed] = useState(false);

  // if (status === "unauthenticated") router.push("/signin");

  // if (status === "loading") {
  //   return "loading";
  // }

  async function handleEnable() {
    //show notification prompt
    let accepted = Notification.permission === "granted";

    if (!accepted) {
      setOverlayShowing(true);
      const choice = await Notification.requestPermission();
      setOverlayShowing(false);
      accepted = choice === "granted";
    }

    if (accepted) {
      toast.dismiss();
      toast("Just a sec...");
      const subscription = await subscribePush().catch((error) => {
        console.log(error);
        toast.error("Failed to subscribe notifications. Please retry.");
        return;
      });

      if (!subscription)
        return toast.error("Can't generate notification subscription.");
      toast.dismiss();
      toast("It takes a sec...");
      const success = await saveSubscription(subscription).catch((error) => {
        console.error(error);
        toast.dismiss();
        toast.error("Failed to save subscription. Please retry.");
        return false;
      });

      if (success) setSubscribed(true);
      if (success) toast.success("Notifications enabled successfully");
      if (success) localStorage.setItem("notifications-prompted", "true");
      // else toast.error("Something went wrong");
    } else toast.error("Failed to enable notifications");

    if (Notification.permission !== "default" && subscribed)
      localStorage.setItem("notifications-prompted", "true");
  }

  function handleDisable() {
    setSubscribed(false);
    // localStorage.setItem("notifications-prompted", "true");
  }

  async function subscribePush() {
    const publicVapidKey =
      process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY ||
      "BHU8mT0M4T8l0n0kM5HME-IKFVqQlbsEbQDD5ihoWrb3QodZA5LAMoujrI7gmqvFxEv3n9oy0gmfE00Hhv4NI4w";
    if (!publicVapidKey) return console.log("VAPID key not found");

    console.log("Checking service worker registration...");
    const register = await navigator.serviceWorker.getRegistration();

    if (!register) {
      return console.log("Service worker not found");
    }
    if (!publicVapidKey) return console.log("VAPID key not found");
    // Register Push
    console.log("Registering Push...");
    const subscription = await register.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(publicVapidKey),
    });
    console.log("Push Registered...");

    return subscription;
  }

  async function saveSubscription(subscription: PushSubscription) {
    const userId = (session?.user as any)?.id;
    if (!userId)
      throw new Error("No user id hence cannot save push subscription");
    const response = await fetch("/api/notifications/save-subscription", {
      method: "POST",
      body: JSON.stringify({
        subscription,
        userId,
      }),
    }).catch((error) => {
      console.error(error);
      throw new Error("Failed to get response when saving subscription");
    });

    if (!response.ok)
      throw new Error(
        "Server returned bad status code when saving subscription"
      );

    return true;
  }

  function urlBase64ToUint8Array(base64String: string) {
    const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding)
      .replace(/\-/g, "+")
      .replace(/_/g, "/");

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  useEffect(() => {
    const checkSubscription = async () => {
      try {
        const register = await navigator.serviceWorker.getRegistration();

        if (!register) {
          console.log("No service worker registration found");
          return;
        }

        const subscription = await register.pushManager.getSubscription();

        if (!subscription) {
          console.log("User is not subscribed to push notifications");
          return;
        }

        console.log("Already subscribed", subscription);
        setSubscribed(true);
      } catch (error) {
        console.error("Error checking subscription:", error);
      }
    };

    checkSubscription();
  }, []);

  return (
    <div className="bg-gray-100 dark:bg-gray-900 ">
      <div
        className={`fixed z-50 inset-0 overflow-hidden dark:bg-white bg-black opacity-20 ${
          overlayShowing ? "" : "hidden"
        }`}
      ></div>
      <div className="p-6 space-y-6  max-w-xl w-[90vw] m-4 mx-auto">
        <div className="space-y-2">
          <h2 className="text-2xl font-extrabold dark:text-white">
            Notifications
          </h2>

          <p className="mb-3 text-gray-500 dark:text-gray-400">
            {" "}
            Enable or disable notifications. When enabled, you'll receive a
            notification each time a new assignment, quiz etc is added to your
            eLearning.
          </p>

          <label
            className={"relative inline-flex items-center cursor-pointer mt-3 "}
          >
            <input
              disabled={status === "loading"}
              onChange={(e) => {
                if (e.target.checked) handleEnable();
                else handleDisable();
              }}
              type="checkbox"
              checked={subscribed}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
            <span className="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300">
              Notifications {subscribed ? "enabled" : "disabled"}
            </span>
          </label>
        </div>

        <hr className="h-px my-8 bg-gray-200 border-0 dark:bg-gray-700"></hr>

        <div className="space-y-2">
          <h2 className="text-xl font-extrabold dark:text-white">
            Notifications format
          </h2>
          <p className="mb-3 text-gray-500 dark:text-gray-400">
            Choose how you prefer to receive notifications:
          </p>
          <div className="flex items-center mb-4">
            <input
              checked
              disabled={!subscribed}
              id="summary"
              type="radio"
              name="notificationFormat"
              value="summary"
              className="w-4 h-4 rounded-full text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600 mr-2"
            />
            <label
              htmlFor="summary"
              className="text-sm font-medium text-gray-900 dark:text-gray-300"
            >
              Summary: Receive one notification summarizing multiple events.
            </label>
          </div>
          <div className="flex items-center">
            <input
              disabled={!subscribed}
              id="individual"
              type="radio"
              name="notificationFormat"
              value="individual"
              className="w-4 h-4 rounded-full text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600 mr-2"
            />
            <label
              htmlFor="individual"
              className="text-sm font-medium text-gray-900 dark:text-gray-300"
            >
              Individual: Get separate notifications for each event.
            </label>
          </div>
          <div className="flex items-center">
            <input
              disabled={!subscribed}
              defaultChecked={!subscribed}
              id="none"
              type="radio"
              name="notificationFormat"
              value="individual"
              className="w-4 h-4 rounded-full text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600 mr-2"
            />
            <label
              htmlFor="none"
              className="text-sm font-medium text-gray-900 dark:text-gray-300"
            >
              None: This option means notifications are disabled.
            </label>
          </div>
        </div>

        <hr className="h-px my-8 bg-gray-200 border-0 dark:bg-gray-700" />
        <div className="space-y-2">
          <h2 className="text-2xl font-extrabold dark:text-white">
            Show Your Support
          </h2>
          <p className="mb-3 text-lg text-gray-500 md:text-xl dark:text-gray-400">
            Your support helps me continue to improving Calendify.
          </p>
          <p className="mb-3 text-gray-500 dark:text-gray-400">
            By continuing to use my app, you help me to:
          </p>

          <ul className="max-w-md space-y-1 text-gray-500 list-inside dark:text-gray-400">
            <li className="flex items-center">
              <svg
                className="w-3.5 h-3.5 me-2 text-green-500 dark:text-green-400 flex-shrink-0"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
              </svg>
              Keep Calendify severs running
            </li>
            <li className="flex items-center">
              <svg
                className="w-3.5 h-3.5 me-2 text-green-500 dark:text-green-400 flex-shrink-0"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
              </svg>
              Continue offering Calendify for free
            </li>
            <li className="flex items-center">
              <svg
                className="w-3.5 h-3.5 me-2 text-green-500 dark:text-green-400 flex-shrink-0"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
              </svg>
              Make more free apps for everyone
            </li>
          </ul>

          <p className="text-sm">
            {" "}
            <span className="inline-block">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500">
                Thank you for your support!
              </span>
            </span>
          </p>
          <button className="relative inline-flex items-center justify-center p-0.5 mb-2 me-2 overflow-hidden text-sm font-medium text-gray-900 rounded-lg group bg-gradient-to-br from-pink-500 to-orange-400 group-hover:from-pink-500 group-hover:to-orange-400 hover:text-white dark:text-white focus:ring-4 focus:outline-none focus:ring-pink-200 dark:focus:ring-pink-800">
            <span className="relative px-5 py-2.5 transition-all ease-in duration-75 bg-white dark:bg-gray-900 rounded-md group-hover:bg-opacity-0">
              Show your Support
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Page;
